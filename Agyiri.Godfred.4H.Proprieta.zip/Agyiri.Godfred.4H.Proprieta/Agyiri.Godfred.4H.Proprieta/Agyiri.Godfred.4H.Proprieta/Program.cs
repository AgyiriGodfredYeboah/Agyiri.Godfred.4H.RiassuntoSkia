﻿using System;

namespace Agyiri.Godfred._4H.Proprieta
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Programma \"Proprieta \" scritto da Agyiri ");

            Quadrato q = new Quadrato(10);
            Console.WriteLine($"lato del quadrato: {q.Lato}");
            Console.WriteLine($"L'area del quadrato: {q._area}");

            q.Lato = 20;
            Console.WriteLine($"lato del quadrato: {q.Lato}");
            Console.WriteLine($"L'area del quadrato: {q._area}");



            q.Area = 144;
            Console.WriteLine($"lato del quadrato: {q.Lato}");
            Console.WriteLine($"L'area del quadrato: {q.Area}");

            for(int val=2; val<10;val++)
            {
                q.Lato++;
                Console.WriteLine($"Lato: {q.Lato}, Area: {q.Area}");
            }

        }
    }

    

    public class Quadrato
    {
        //field lato(visibile dall'esterno, viola l'incapsulamento previsto dalla OOP)
        private double _lato;

        //Property lato
        public double Lato
        {
            //se nella Property c'è solo Get, sto facendo una read only
            get
            {
                return _lato;
            }

            set
            {
                _lato = value;
                _area = _lato * _lato;//viola il principio di singola responsabilità
            }
        }

        public double _area;//Questo field è ridondante e viene da una progettazione
        //E sufficiente
        public double Area
        {
            get
            {
                return _lato * _lato;
            }

            set
            {
                _lato = Math.Sqrt(value);
            }
        }

      
        public Quadrato()//costruttore di default senza parametri
        {
            Lato = Lato;
        }
        public Quadrato(double lato)//costruttore che parte dal lato
        {
         if(lato >= 0){
                _lato = lato;
                _area = lato * lato;
            }
            else {
                _lato = -lato;
                _area = _lato * _lato;
            }
        }



        

      
    }

}
