﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Agyiri.Godfred.Gatto._4H.Models;

namespace Agyiri.Godfred.Gatto._4H
{
    public partial class frmMain : Form
    {
        // foglio di quaderno 20 cm x 30 cm
        const int LATO_X = 200;
        const int LATO_Y = 300;

        const int MARGINE_SINISTRO = 100;
        const int MARGINE_DESTRO = 100;
        const int MARGINE_SUPERIORE = 100;
        const int MARGINE_INFERIORE = 100;


        const int LATO_X_FORM = (MARGINE_SINISTRO + LATO_X + MARGINE_DESTRO);
        const int LATO_Y_FORM = (MARGINE_SUPERIORE + LATO_Y + MARGINE_INFERIORE);

        public frmMain()
        {
            InitializeComponent();
            // blocco il form alle dimensioni fissate (okkio!! tiene conto anche della banda superiore e laterale)
            this.MinimumSize = new Size(LATO_X_FORM, LATO_Y_FORM);
            this.MaximumSize = new Size(LATO_X_FORM, LATO_Y_FORM);

        }

        private int X(double x)
        {
            int xLogico = 0;
            xLogico = (int)(x) + MARGINE_SINISTRO;
            return xLogico;
        }

        private int Y(double y)
        {
            int yLogico = 0;
            yLogico = (MARGINE_SUPERIORE + LATO_Y - (int)(y));
            return yLogico;
        }

        private void btnCalcola_Click(object sender, EventArgs e)
        {
            int i = 0;
            Graphics dc = this.CreateGraphics();
            Pen BluePen = new Pen(Color.Blue, 1);
            Pen RedPen = new Pen(Color.Red, 1);

            dc.DrawRectangle(BluePen, MARGINE_SINISTRO + 0, MARGINE_SUPERIORE + 0, LATO_X, LATO_Y);

            Punto[] Corpo = new Punto[10];
            Punto[] pt = new Punto[10];
            Punto[] faccia = new Punto[10];

            Corpo[0] = new Punto(10, 0);
            Corpo[1] = new Punto(20, 0);
            Corpo[2] = new Punto(30, 0);
            Corpo[3] = new Punto(40, 10);
            Corpo[4] = new Punto(50, 10);
            Corpo[5] = new Punto(60, 10);
            Corpo[6] = new Punto(00, 70);
            Corpo[7] = new Punto(00, 20);
            Corpo[8] = new Punto(00, 30);
            Corpo[9] = new Punto(10, 40);



            faccia[0] = new Punto(0,30);


            for (i = 0; i < 10; i++)
            //dc.DrawLine(BluePen, X(p[i].X), Y(p[i].Y), X(p[i+1].X), Y(p[i+1].Y));

            {
                int j = i + 1;
                if (j == 10) j = 0;
                dc.DrawLine(BluePen, X(Corpo[i].X), Y(Corpo[i].Y), X(Corpo[j].X), Y(Corpo[j].Y));
                dc.DrawLine(BluePen, X(faccia[i].X), Y(faccia[i].Y), X(faccia[j].X), Y(faccia[j].Y));
            }



            for (i = 0; i < 11; i++)
            {
                pt[i] = new Punto(0, 0);
                //pt[i] = p[i].Trasla(-50, 50);
                pt[i] = Corpo[i].Scala(2, 3);
                pt[i] = faccia[i].Scala(2, 3);
            }

            for (i = 0; i < 11; i++)

            {
                int j = i + 1;
                if (j == 6) j = 0;
                dc.DrawLine(RedPen, X(pt[i].X), Y(pt[i].Y), X(pt[j].X), Y(pt[j].Y));
            }


            //dc.DrawLine(BluePen, 0, 0, 100, 100);
            //dc.DrawLine(BluePen, 0, 0, 200, 300);




            //// linea diagonale per vedere lo spazio attorno al foglio
            //dc.DrawLine(BluePen, X(0), Y(0), X(LATO_X), Y(LATO_Y));
            //dc.DrawLine(BluePen, X(0), Y(LATO_Y), X(LATO_X), Y(0));

            //dc.DrawLine(BluePen, X(4), Y(12), X(18), Y(20.5));
            //dc.DrawLine(BluePen, X(10), Y(20.5), X(16), Y(10));
            //dc.DrawLine(BluePen, X(16), Y(10), X(4), Y(10));





        }
    }
}
