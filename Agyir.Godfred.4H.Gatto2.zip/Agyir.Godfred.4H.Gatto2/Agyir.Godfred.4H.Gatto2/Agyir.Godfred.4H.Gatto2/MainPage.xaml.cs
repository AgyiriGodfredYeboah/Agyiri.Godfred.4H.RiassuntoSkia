﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;
using SkiaSharp;
using Xamarin.Essentials;
using System.IO;

namespace Agyir.Godfred._4H.Gatto2
{
    // Learn more about making custom code visible in the Xamarin.Forms previewer
    // by visiting https://aka.ms/xamarinforms-previewer
    [DesignTimeVisible(false)]
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private void SKCanvasView (object sender, SkiaSharp.Views.Forms.SKPaintSurfaceEventArgs e)
        {
            e.Surface.Canvas.Clear();

            SKPath linea = new SKPath();

            SKPoint p = new SKPoint(0, 0);
            linea.MoveTo(p);

            p = new SKPoint(200, 200);
            linea.LineTo(p);

            p = new SKPoint(400, 0);
            linea.LineTo(p);

            SKPaint paint = new SKPaint
            {
                Style = SKPaintStyle.Stroke,
                Color = SKColors.Red,
                StrokeWidth = 5,

            };

            e.Surface.Canvas.DrawPath(linea, paint);



        }
        SKPath Gatto = new SKPath(); 


        private async void btnCarica_Clicked(object sender, EventArgs e)
        {
            var cacheDir = FileSystem.CacheDirectory;

            var mainDir = FileSystem.AppDataDirectory;

            var stream = await FileSystem.OpenAppPackageFileAsync("Gatto.csv");
            var reader = new StreamReader(stream);
            while(!reader.EndOfStream)
            {
                string str = reader.ReadLine();
                string[] colonne = str.Split(';');
                float X, Y;
                float.TryParse(colonne[0], out X);
                float.TryParse(colonne[1], out Y);

                SKPoint p = new SKPoint(X, Y);

                if (colonne[0] == "L")
                    Gatto.LineTo(p);

                else if (colonne[0] == "M")
                    Gatto.MoveTo(p);

            }
        }



    }
}
